﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;



namespace Carental1.Models
{
    public class Category
    {
        //[Key]
        //[DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int IdCategory { get; set; }    
        public string CategoryName { get; set; }
        public string Type { get; set; }
        public List<Car> Cars { get; set; } 
    }
}
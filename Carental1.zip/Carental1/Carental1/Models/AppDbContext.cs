﻿using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using System;
using Carental1.Models;

namespace Carental1.Models
{
    public class AppDbContext : IdentityDbContext<IdentityUser>
    {
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options)
        {

        }
        public DbSet<Car> Cars { get; set; }
        public DbSet<Person> Person { get; set; }
        public DbSet<Rental> Rental { get; set; }
        public DbSet<PersonAddress> PersonAddress { get; set; }
        public DbSet<Category> Categories { get; set; }
        //protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        //{
        //    if (!optionsBuilder.IsConfigured)
        //    {
        //        optionsBuilder.UseSqlServer("Server = (localdb)\\mssqllocaldb; Database =Carental; Trusted_Connection = True; MultipleActiveResultSets = true");
        //    }
        //}

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.Entity<Category>().HasData(new Category { IdCategory = 1, CategoryName = "Sedan" });
            modelBuilder.Entity<Category>().HasData(new Category { IdCategory = 2, CategoryName = "Hatchback" });
            modelBuilder.Entity<Category>().HasData(new Category { IdCategory = 3, CategoryName = "Honda" });


            modelBuilder.Entity<Car>().HasData(new Car
            {
                IdCar = 1,
                Model = "Mahindra Scorpio",
                Price = 16678,
                Description = "Policie",

                Mileage = 20,
                ImageUrl = "",
                IdCategory = 1

            });

            modelBuilder.Entity<Car>().HasData(new Car
            {
                IdCar = 2,
                Model = "Mahindra Scorpio",
                Price = 16678,

                Description = "Policie" +
                "Cancellation: Cancellation made after booking start: No refund " +
                "Cancellation made more than 24 hours before the booking start: Rs 200" +
                "Cancellation made with 24 hours of booking start: Rs 200 or 50 % of Booking fee(whichever is greater)" +
                "Late Return:" +
                "Standard hourly fee will be applicable per hour of delay.Weekend or weekday delays will be charged accordingly." +
                "In addition to the standard hourly fee, every hour of delay would be charged at Rs. 300 / hour" +
                "Vehicle Damage: Any unintentional damage or accident will be liable for damage charge upto Rs 10000 / -(full - wrap insurance covers the rest) ",
                Mileage = 20,
                ImageUrl = "",
                IdCategory = 2
            });

            modelBuilder.Entity<Car>().HasData(new Car
            {
                IdCar = 3,
                Model = "Mahindra Scorpio",
                Price = 16678,

                Description = "Policie" +
               "Cancellation: Cancellation made after booking start: No refund " +
               "Cancellation made more than 24 hours before the booking start: Rs 200" +
               "Cancellation made with 24 hours of booking start: Rs 200 or 50 % of Booking fee(whichever is greater)" +
               "Late Return:" +
               "Standard hourly fee will be applicable per hour of delay.Weekend or weekday delays will be charged accordingly." +
               "In addition to the standard hourly fee, every hour of delay would be charged at Rs. 300 / hour" +
               "Vehicle Damage: Any unintentional damage or accident will be liable for damage charge upto Rs 10000 / -(full - wrap insurance covers the rest) ",
                Mileage = 20,
                ImageUrl = "",
                IdCategory = 3

            });

            modelBuilder.Entity<Car>().HasData(new Car
            {
                IdCar = 4,
                Model = "Mahindra Scorpio",
                Price = 16678,

                Description = "Policie" +
               "Cancellation: Cancellation made after booking start: No refund " +
               "Cancellation made more than 24 hours before the booking start: Rs 200" +
               "Cancellation made with 24 hours of booking start: Rs 200 or 50 % of Booking fee(whichever is greater)" +
               "Late Return:" +
               "Standard hourly fee will be applicable per hour of delay.Weekend or weekday delays will be charged accordingly." +
               "In addition to the standard hourly fee, every hour of delay would be charged at Rs. 300 / hour" +
               "Vehicle Damage: Any unintentional damage or accident will be liable for damage charge upto Rs 10000 / -(full - wrap insurance covers the rest) ",
                Mileage = 20,
                ImageUrl = "",
                IdCategory = 2
            });

            modelBuilder.Entity<Car>().HasData(new Car
            {
                IdCar = 5,
                Model = "Mahindra Scorpio",
                Price = 16678,

                Description = "Policie" +
               "Cancellation: Cancellation made after booking start: No refund " +
               "Cancellation made more than 24 hours before the booking start: Rs 200" +
               "Cancellation made with 24 hours of booking start: Rs 200 or 50 % of Booking fee(whichever is greater)" +
               "Late Return:" +
               "Standard hourly fee will be applicable per hour of delay.Weekend or weekday delays will be charged accordingly." +
               "In addition to the standard hourly fee, every hour of delay would be charged at Rs. 300 / hour" +
               "Vehicle Damage: Any unintentional damage or accident will be liable for damage charge upto Rs 10000 / -(full - wrap insurance covers the rest) ",
                Mileage = 20,
                ImageUrl = "",
                IdCategory = 2

            });
            modelBuilder.Entity<Car>().HasData(new Car
            {
                IdCar = 6,
                Model = "Mahindra Scorpio",
                Price = 16678,

                Description = "Policie" +
                           "Cancellation: Cancellation made after booking start: No refund " +
                           "Cancellation made more than 24 hours before the booking start: Rs 200" +
                           "Cancellation made with 24 hours of booking start: Rs 200 or 50 % of Booking fee(whichever is greater)" +
                           "Late Return:" +
                           "Standard hourly fee will be applicable per hour of delay.Weekend or weekday delays will be charged accordingly." +
                           "In addition to the standard hourly fee, every hour of delay would be charged at Rs. 300 / hour" +
                           "Vehicle Damage: Any unintentional damage or accident will be liable for damage charge upto Rs 10000 / -(full - wrap insurance covers the rest) ",
                Mileage = 20,
                ImageUrl = "",
                IdCategory = 1

            });
            modelBuilder.Entity<Car>().HasData(new Car
            {
                IdCar = 7,
                Model = "Mahindra Scorpio",
                Price = 16678,

                Description = "Policie" +
               "Cancellation: Cancellation made after booking start: No refund " +
               "Cancellation made more than 24 hours before the booking start: Rs 200" +
               "Cancellation made with 24 hours of booking start: Rs 200 or 50 % of Booking fee(whichever is greater)" +
               "Late Return:" +
               "Standard hourly fee will be applicable per hour of delay.Weekend or weekday delays will be charged accordingly." +
               "In addition to the standard hourly fee, every hour of delay would be charged at Rs. 300 / hour" +
               "Vehicle Damage: Any unintentional damage or accident will be liable for damage charge upto Rs 10000 / -(full - wrap insurance covers the rest) ",
                Mileage = 20,
                ImageUrl = "",
                IdCategory = 1


            });

            modelBuilder.Entity<Car>().HasData(new Car
            {
                IdCar = 8,
                Model = "Mahindra Scorpio",
                Price = 16678,

                Description = "Policie" +
                "Cancellation: Cancellation made after booking start: No refund " +
                "Cancellation made more than 24 hours before the booking start: Rs 200" +
                "Cancellation made with 24 hours of booking start: Rs 200 or 50 % of Booking fee(whichever is greater)" +
                "Late Return:" +
                "Standard hourly fee will be applicable per hour of delay.Weekend or weekday delays will be charged accordingly." +
                "In addition to the standard hourly fee, every hour of delay would be charged at Rs. 300 / hour" +
                "Vehicle Damage: Any unintentional damage or accident will be liable for damage charge upto Rs 10000 / -(full - wrap insurance covers the rest) ",
                Mileage = 20,
                ImageUrl = "",
                IdCategory = 2

            });
            modelBuilder.Entity<Car>().HasData(new Car
            {
                IdCar = 9,
                Model = "Mahindra Scorpio",
                Price = 16678,

                Description = "Policie" +
                "Cancellation: Cancellation made after booking start: No refund " +
                "Cancellation made more than 24 hours before the booking start: Rs 200" +
                "Cancellation made with 24 hours of booking start: Rs 200 or 50 % of Booking fee(whichever is greater)" +
                "Late Return:" +
                "Standard hourly fee will be applicable per hour of delay.Weekend or weekday delays will be charged accordingly." +
                "In addition to the standard hourly fee, every hour of delay would be charged at Rs. 300 / hour" +
                "Vehicle Damage: Any unintentional damage or accident will be liable for damage charge upto Rs 10000 / -(full - wrap insurance covers the rest) ",
                Mileage = 20,
                ImageUrl = "",
                IdCategory = 1

            });

            modelBuilder.Entity<Car>().HasData(new Car
            {
                IdCar = 10,
                Model = "Mahindra Scorpio",
                Price = 16678,

                Description = "Policie" +
                "Cancellation: Cancellation made after booking start: No refund " +
                "Cancellation made more than 24 hours before the booking start: Rs 200" +
                "Cancellation made with 24 hours of booking start: Rs 200 or 50 % of Booking fee(whichever is greater)" +
                "Late Return:" +
                "Standard hourly fee will be applicable per hour of delay.Weekend or weekday delays will be charged accordingly." +
                "In addition to the standard hourly fee, every hour of delay would be charged at Rs. 300 / hour" +
                "Vehicle Damage: Any unintentional damage or accident will be liable for damage charge upto Rs 10000 / -(full - wrap insurance covers the rest) ",
                Mileage = 20,
                ImageUrl = "",
                IdCategory = 3
            });

            modelBuilder.Entity<Car>().HasData(new Car
            {
                IdCar = 11,
                Model = "Mahindra Scorpio",
                Price = 16678,

                Description = "Policie" +
                 "Cancellation: Cancellation made after booking start: No refund " +
                 "Cancellation made more than 24 hours before the booking start: Rs 200" +
                 "Cancellation made with 24 hours of booking start: Rs 200 or 50 % of Booking fee(whichever is greater)" +
                 "Late Return:" +
                 "Standard hourly fee will be applicable per hour of delay.Weekend or weekday delays will be charged accordingly." +
                 "In addition to the standard hourly fee, every hour of delay would be charged at Rs. 300 / hour" +
                 "Vehicle Damage: Any unintentional damage or accident will be liable for damage charge upto Rs 10000 / -(full - wrap insurance covers the rest) ",
                Mileage = 20,
                ImageUrl = "",
                IdCategory = 2
            });
        }
    }
}
    
 


       


        

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Carental1.Models
{
    public class IPersonRepository
    {
        IEnumerable<Person> AllPerson { get; }
    }
}

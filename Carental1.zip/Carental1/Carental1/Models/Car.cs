﻿using Carental1.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Carental1.Models
{
    public class Car
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int IdCar { get; set; }
        public int IdCategory { get; set; }
        public string Model { get; set; }
        
        //public string Registration_number { get; set; }
        public decimal Price { get; set; }     
        public string Description { get; set; }       
        public int Mileage { get; set; }  
        public string ImageUrl { get; set; }
        //public List<Car> AllCar { get; set; }

    }
}

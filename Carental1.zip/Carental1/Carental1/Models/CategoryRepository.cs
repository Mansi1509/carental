﻿using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;

namespace Carental1.Models
{

    public class CategoryRepository : ICategoryRepository
    {
        private readonly AppDbContext _appdbcontext;

        public CategoryRepository(AppDbContext appdbcontext)
        {
            _appdbcontext = appdbcontext;
        }

        public  IEnumerable<Category> AllCategories
        {
            get
            {
                return _appdbcontext.Categories.ToList();
            }


        }
    }
}

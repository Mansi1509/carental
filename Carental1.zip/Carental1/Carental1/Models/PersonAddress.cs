﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace Carental1.Models
{
    public class PersonAddress

    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int IdPersonAddress { get; set; }
        public string Street_Name { get; set; }
        public string Street_Number { get; set; }
        public Char City { get; set; }
        public Char State { get; set; }
        public int UserId { get; set; }
        public int IdCar { get; set; }
    }
}

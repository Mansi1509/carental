﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Carental1.Models
{
    public class PersonAddressRepository
    {
        private readonly AppDbContext _appdbcontext;

        public PersonAddressRepository(AppDbContext appdbcontext)
        {
            _appdbcontext = appdbcontext;
        }

        public IEnumerable<PersonAddress> allpersonaddress => _appdbcontext.PersonAddress;
    }
}

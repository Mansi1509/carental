﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Carental1.Models
{
    public class PersonRepository
    {
       
            private readonly AppDbContext _appdbcontext;

            public PersonRepository(AppDbContext appdbcontext)
            {
                _appdbcontext = appdbcontext;
            }

            public IEnumerable<Person> allperson => _appdbcontext.Person;


        
    }
}

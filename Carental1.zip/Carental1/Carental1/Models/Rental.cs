﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Carental1.Models
{
    public class Rental
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int IdRental { get; set; }      
        public DateTime PICKUP_Start { get; set; }     
        public DateTime DROPOFF { get; set; }   
        public string Priceperday { get; set; }
        public float Estimated_Km { get; set; }    
        public int UserId  { get; set; }
        public int IdCar { get; set; }
    }
}
